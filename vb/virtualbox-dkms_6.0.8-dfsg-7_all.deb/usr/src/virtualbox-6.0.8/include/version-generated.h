#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 6
#define VBOX_VERSION_MINOR 0
#define VBOX_VERSION_BUILD 8
#define VBOX_VERSION_STRING_RAW "6.0.8"
#define VBOX_VERSION_STRING "6.0.8_Ubuntu"
#define VBOX_API_VERSION_STRING "6_0"

#define VBOX_PRIVATE_BUILD_DESC "Private build by buildd"

#endif
